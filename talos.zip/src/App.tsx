import { lazy, Suspense, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import { Layout } from './components/Layout';
import { LoadingScreen } from './components/LoadingScreen';
import { RouteMetadataManager } from './components/RouteMetadataManager';

// ── Public pages — eagerly imported for seamless SSG hydration ─────────────
import Home from './pages/Home';
import Services from './pages/Services';
import Studio from './pages/Studio';
import Contact from './pages/Contact';
import Careers from './pages/Careers';
import Projects from './pages/Projects';
import Expertise from './pages/Expertise';
import Impact from './pages/Impact';
import Insights from './pages/Insights';
import ProjectPresence from './pages/ProjectPresence';
import ProjectAutomation from './pages/ProjectAutomation';
import ProjectCustom from './pages/ProjectCustom';
import ProjectMedilife from './pages/ProjectMedilife';
import ServiceWebDesign from './pages/ServiceWebDesign';
import ServiceChatbots from './pages/ServiceChatbots';
import ServiceAutomation from './pages/ServiceAutomation';
import OfferHospitality from './pages/OfferHospitality';
import OfferEcommerce from './pages/OfferEcommerce';
import OfferProfessional from './pages/OfferProfessional';
import Legal from './pages/Legal';

// ── Admin panel — lazy loaded as a group ────────────────────────────────────
const AdminLayout = lazy(() => import('./admin/components/AdminLayout'));
const AdminDashboard = lazy(() => import('./admin/pages/AdminDashboard'));
const AdminProjects = lazy(() => import('./admin/pages/AdminProjects'));
const AdminTeam = lazy(() => import('./admin/pages/AdminTeam'));
const AdminCaseStudies = lazy(() => import('./admin/pages/AdminCaseStudies'));
const AdminSettings = lazy(() => import('./admin/pages/AdminSettings'));
const AdminInquiries = lazy(() => import('./admin/pages/AdminInquiries'));
const AdminLeads = lazy(() => import('./admin/pages/AdminLeads'));
const AdminInvoices = lazy(() => import('./admin/pages/AdminInvoices'));
const ProjectDetail = lazy(() => import('./admin/pages/ProjectDetail'));
const CaseStudyDetail = lazy(() => import('./admin/pages/CaseStudyDetail'));
const AdminProfile = lazy(() => import('./admin/pages/AdminProfile'));

// ── Client portal — lazy loaded ──────────────────────────────────────────────
const PortalLogin = lazy(() => import('./portal/PortalLogin'));
const PortalDashboard = lazy(() => import('./portal/PortalDashboard'));
const PortalProfile = lazy(() => import('./portal/PortalProfile'));

// Minimal fallback — invisible, keeps layout stable (no spinner flash)
const PageFallback = () => (
  <div style={{ minHeight: '60vh' }} aria-hidden="true" />
);

export function AppRoutes({ isInitializing, onInitComplete }: { isInitializing?: boolean; onInitComplete?: () => void }) {
  return (
    <>
      <RouteMetadataManager />
      {isInitializing && onInitComplete && <LoadingScreen onComplete={onInitComplete} />}
      <ScrollToTop />
      <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="expertise" element={<Expertise />} />
            <Route path="impact" element={<Impact />} />
            <Route path="insights" element={<Insights />} />
            <Route path="services" element={<Services />} />
            <Route path="about" element={<Studio />} />
            <Route path="contact" element={<Contact />} />
            <Route path="careers" element={<Careers />} />
            <Route path="projects" element={<Projects />} />
            <Route path="projects/presence" element={<ProjectPresence />} />
            <Route path="projects/automation" element={<ProjectAutomation />} />
            <Route path="projects/custom" element={<ProjectCustom />} />
            <Route path="projects/medilife" element={<ProjectMedilife />} />
            <Route path="services/web-design" element={<ServiceWebDesign />} />
            <Route path="services/chatbots" element={<ServiceChatbots />} />
            <Route path="services/automation" element={<ServiceAutomation />} />
            <Route path="offers/hospitality" element={<OfferHospitality />} />
            <Route path="offers/ecommerce" element={<OfferEcommerce />} />
            <Route path="offers/professional" element={<OfferProfessional />} />
            <Route path="legal" element={<Legal />} />
          </Route>

          {/* Client Portal */}
          <Route path="/portal" element={<PortalLogin />} />
          <Route path="/portal/dashboard" element={<PortalDashboard />} />
          <Route path="/portal/profile" element={<PortalProfile />} />

          {/* Admin Panel */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="projects" element={<AdminProjects />} />
            <Route path="projects/:id" element={<ProjectDetail />} />
            <Route path="case-studies" element={<AdminCaseStudies />} />
            <Route path="case-studies/:id" element={<CaseStudyDetail />} />
            <Route path="team" element={<AdminTeam />} />
            <Route path="inquiries" element={<AdminInquiries />} />
            <Route path="leads" element={<AdminLeads />} />
            <Route path="invoices" element={<AdminInvoices />} />
            <Route path="profile" element={<AdminProfile />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>
        </Routes>
      </Suspense>
    </>
  );
}

function App() {
  const [isInitializing, setIsInitializing] = useState(true);

  return (
    <BrowserRouter>
      <AppRoutes isInitializing={isInitializing} onInitComplete={() => setIsInitializing(false)} />
    </BrowserRouter>
  );
}

export default App;
