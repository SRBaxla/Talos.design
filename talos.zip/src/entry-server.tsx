import { renderToString } from 'react-dom/server';
import { MemoryRouter, Routes, Route } from 'react-router';
import { Layout } from './components/Layout';

// Eager imports for static prerendering pass
import Home from './pages/Home';
import Expertise from './pages/Expertise';
import Impact from './pages/Impact';
import Insights from './pages/Insights';
import Services from './pages/Services';
import Studio from './pages/Studio';
import Contact from './pages/Contact';
import Careers from './pages/Careers';
import Projects from './pages/Projects';
import ProjectPresence from './pages/ProjectPresence';
import ProjectAutomation from './pages/ProjectAutomation';
import ProjectCustom from './pages/ProjectCustom';
import ProjectMedilife from './pages/ProjectMedilife';
import ServiceWebDesign from './pages/ServiceWebDesign';
import ServiceChatbots from './pages/ServiceChatbots';
import ServiceAutomation from './pages/ServiceAutomation';
import OfferHospitality from './pages/OfferHospitality';
import OfferEcommerce from './pages/OfferEcommerce';
import OfferProfessional from './pages/OfferProfessional';
import Legal from './pages/Legal';

export function render(url: string): { html: string } {
  const html = renderToString(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="expertise" element={<Expertise />} />
          <Route path="impact" element={<Impact />} />
          <Route path="insights" element={<Insights />} />
          <Route path="services" element={<Services />} />
          <Route path="about" element={<Studio />} />
          <Route path="contact" element={<Contact />} />
          <Route path="careers" element={<Careers />} />
          <Route path="projects" element={<Projects />} />
          <Route path="projects/presence" element={<ProjectPresence />} />
          <Route path="projects/automation" element={<ProjectAutomation />} />
          <Route path="projects/custom" element={<ProjectCustom />} />
          <Route path="projects/medilife" element={<ProjectMedilife />} />
          <Route path="services/web-design" element={<ServiceWebDesign />} />
          <Route path="services/chatbots" element={<ServiceChatbots />} />
          <Route path="services/automation" element={<ServiceAutomation />} />
          <Route path="offers/hospitality" element={<OfferHospitality />} />
          <Route path="offers/ecommerce" element={<OfferEcommerce />} />
          <Route path="offers/professional" element={<OfferProfessional />} />
          <Route path="legal" element={<Legal />} />
        </Route>
      </Routes>
    </MemoryRouter>
  );

  return { html };
}

export { getRouteMetadata, PUBLIC_ROUTE_METADATA } from './data/routeMetadata';
export type { RouteMetadata } from './data/routeMetadata';
